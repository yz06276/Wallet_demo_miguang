public class ContractCreationDecoration: TransactionDecoration {

    public override func tags() -> [String] {
        ["contractCreation"]
    }

}
