open class TransactionDecoration {

    public init() {
    }

    open func tags() -> [String] {
        []
    }
    
}
