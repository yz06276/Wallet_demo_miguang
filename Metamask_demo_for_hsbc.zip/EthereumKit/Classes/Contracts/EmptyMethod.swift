public class EmptyMethod: ContractMethod {
}
