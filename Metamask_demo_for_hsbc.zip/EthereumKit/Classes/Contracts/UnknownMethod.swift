//import Foundation
//
//public class UnknownMethod: ContractMethod {
//    public let id: Data
//    public let inputArguments: Data
//
//    init(id: Data, inputArguments: Data) {
//        self.id = id
//        self.inputArguments = inputArguments
//    }
//
//}
