enum MessageDecodeError: Error {
    case notEnoughFields
    case fieldNotFound
}
