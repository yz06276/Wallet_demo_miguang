import BigInt

class EthereumKitState {
    var accountState: AccountState?
    var lastBlockHeight: Int?
}
