public enum WordsSyncMode {
    case api
    case spv
    case geth
}
