//
//  Metamask_demo_for_hsbcApp.swift
//  Metamask_demo_for_hsbc
//
//  Created by Mi Leo on 5/21/22.
//

import SwiftUI

@main
struct Metamask_demo_for_hsbcApp: App {
    var body: some Scene {
        WindowGroup {
            Wallet()
        }
    }
}
